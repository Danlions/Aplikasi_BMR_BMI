#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#define _N "\033[0m" //reset
#define _NG "\033[32m" //normal-green
#define _NY "\033[33m" //normal-yellow
#define _NR "\033[31m" //normal-red
#define _BG "\033[1;32m" //bold-green
#define _BY "\033[1;33m" //bold-yellow
#define _BB "\033[1;34m" //bold-blue
#define _IY "\033[3;33m" //italic-yellow
#ifdef _WIN32
#define clrscr() system("cls")
#else
#define clrscr() system("clear")
#endif

// >>> Struktur data
typedef struct {
    char nama[26];
    int jkel;
    char usr[9];
    char psw[9];
    char kdusr[5];
} User;
typedef struct {
    int umur;
    float berat;
    int tinggi;
    char kdaktiv[4];
    char tgl[9];
    char kdusr[5];
} History;
typedef struct {
    char aktivitas[35];
    char kdaktiv[2];
} Aktivitas;
// <<< Struktur data

// >>> Variabel/Konstanta (Global)
char* FlUser="users.txt";  //nama file data untuk users
char* FlHistory="histories.txt";  //nama file data untuk history
char* FlUser2="users.bak";  //nama file data untuk users (backup)
char* FlHistory2="histories.bak";  //nama file data untuk history (backup)
int JmlDtUser, JmlDtHistory; //jumlah data untuk masing-masing array
int BufferDtUser=50; //jumlah array kosong untuk inputan data users baru
int BufferDtHistory=100; //jumlah array kosong untuk inputan data histories baru (2x jumlah users)
int KdUserAkhir; //untuk menyimpan kode_user paling akhir, nanti ditambah 1 untuk setiap tambahan user baru
const char AdminUsr[]="admin"; //user admin
const char AdminPsw[]="owner777"; //password admin
int LogLev; //1=admin atau 2=users
char LogNama[26]; //untuk menyimpan nama_user yang sedang login
char LogKdUser[5]; //untuk menyimpan kode_user yang sedang login
int menu; //untuk pilihan menu utama
// <<< Variabel/Konstanta (Global)

char* BMI(float br,int tg,int i) { //Body Mass Index
    float bmi, tg2;
    static char ret[300]; memset(ret,0,sizeof(ret));
    tg2=(float)tg/100; ///konversi centimeter ke meter
    bmi=br/(tg2*tg2); //rumus BMI
    if(i==1) { //untuk tampilan informasi detail
        if (bmi<18.5) {
            strcpy(ret,"  KATEGORI: Kurus (Underweight)\n");
            strcat(ret,"  ANJURAN:\n");
            strcat(ret,"  - Makanan: Tambahkan makanan tinggi kalori seperti alpukat, kacang-kacangan, dan produk susu penuh lemak\n");
            strcat(ret,"  - Minuman: Susu protein tinggi atau smoothies dengan buah-buahan dan yogurt\n");
            strcat(ret,"  - Olahraga: Latihan kekuatan seperti angkat beban untuk membangun otot");
        }
        else if (bmi<25) {
            strcpy(ret,"  KATEGORI: Normal/Ideal (Healthy Weight)\n");
            strcat(ret,"  ANJURAN:\n");
            strcat(ret,"  - Makanan: Pertahankan pola makan seimbang dengan sayuran, buah-buahan, protein tanpa lemak, dan biji-bijian\n");
            strcat(ret,"  - Minuman: Air putih atau teh hijau tanpa gula\n");
            strcat(ret,"  - Olahraga: Kombinasi antara latihan kardio (lari, bersepeda) dan kekuatan");
        } else if (bmi<30) {
            strcpy(ret,"  KATEGORI: Berat berlebih (Overweight)\n");
            strcat(ret,"  ANJURAN:\n");
            strcat(ret,"  - Makanan: Pilih makanan rendah kalori seperti sayuran hijau, protein tanpa lemak, dan biji-bijian utuh\n");
            strcat(ret,"  - Minuman: Air putih atau infused water; hindari minuman manis\n");
            strcat(ret,"  - Olahraga: Latihan kardio intensitas sedang seperti jalan cepat atau aerobik");
        } else {
            strcpy(ret,"  KATEGORI: Obesitas (Obesity)\n");
            strcat(ret,"  ANJURAN:\n");
            strcat(ret,"  - Makanan: Fokus pada makanan rendah kalori dengan porsi terkontrol seperti sayuran, protein tanpa lemak, dan kacang-kacangan\n");
            strcat(ret,"  - Minuman: Air putih, hindari minuman berkalori tinggi seperti soda atau jus kemasan\n");
            strcat(ret,"  - Olahraga: Mulai dengan olahraga ringan seperti jalan kaki atau berenang, kemudian tingkatkan intensitas secara bertahap");
        }
    } else if(i==2) { //untuk tampilan informasi pendek
        if (bmi<18.5) strcpy(ret,"Kurus");
        else if (bmi>=18.5 && bmi<25) strcpy(ret,"Normal/Ideal");
        else if (bmi>=25 && bmi<30) strcpy(ret,"Berat berlebih");
        else strcpy(ret,"Obesitas");
    }
    return ret;
}

char* BMR(int jk,int umr,float br,int tg,char* kd) {  //Basal Metabolic Rate (berdasarkan RUMUS: MIFFLIN-ST JEOR)
    float kh;
    static char ret[7];
    //rumus BMR Total Energy Expenditure (TEE) berdasarkan RUMUS: MIFFLIN-ST JEOR
//    if(jk==l) kh = 10 * br + 6.25 * tg - 5 * umr + 5; //pria: TEE = 10 * berat badan + 6.25 * tinggi badan - 5 * umur + 5
//    else kh = 10 * br + 6.25 * tg - 5 * umr - 161; //wanita: TEE = 10 * berat badan + 6.25 * tinggi badan - 5 * umur - 161
kh = 10 * br + 6.25 * tg - 5 * umr + 5;  ///testing sementara
    if(strcmp(kd,"101")==0) kh *= 1.2; //sedentari
    else if(strcmp(kd,"102")==0) kh *= 1.375; //ringan
    else if(strcmp(kd,"103")==0) kh *= 1.55; //sedang
    else kh *= 1.725; //berat
    sprintf(ret,"%7.2f",kh); ///konversi float ke array char
    return ret;
}

int PeriksaFileData(char fldt[10]) { ///param: nama_file di var global: FlUser atau FlHistory
    FILE *fdt; ///deklarasi variabel tipe file
    printf(_BB);
    if((fdt=fopen(fldt,"r"))==NULL) { ///coba buka file data, bila NULL artinya file data belum ada (r = untuk dibaca saja)
        fdt=fopen(fldt,"w"); ///buat file data baru (w = buat baru & untuk diisi)
        fclose(fdt); ///tutup file data
        printf("     File Data [%s] Tidak Ditemukan!  File data baru dibuat..\n",fldt); printf(_N);
        return 0;
    } else {
        int c=0;
        char ch;
        while((ch=fgetc(fdt))!=EOF) if(ch=='\n') c++; ///baca file data baris-perbaris (untuk hitung jumlah data)
        fclose(fdt); ///tutup file data
        printf("     File Data [%s] Ditemukan.  Jumlah data: %i\n",fldt,c); printf(_N);
        return c;
    }
}

void LoadFileDataUserKeArray(User *dt) { ///param: pointer ke array: Users; nama_file; true/false untuk atur kemuncul pesan atau tidak
    memset(dt,0,sizeof(dt)); ///membersihkan isi array Users
    FILE *fdt; ///deklarasi variabel tipe file
    fdt=fopen(FlUser,"r"); ///buka file users.txt mode baca saja
    char baris[100], c[1]; ///baris= untuk simpan teks perbaris; c= bantuan untuk konversi
    int ke=0; ///untuk index array ke 0,1,2,3,...
    //while (fscanf(fdt,"%25s %d %8s %8s %4s", dt[ke].nama,dt[ke].jkel,dt[ke].usr,dt[ke].psw,dt[ke].kdusr)==5 && ke<JmlDtUser) ke++;
    while(fgets(baris,sizeof(baris),fdt)) {  ///baca 1 baris teks dari file users.txt selama masih ada baris
        //for(int i=28; i<46; i++) printf("%c",baris[i]); printf("\n"); ///untuk testing
        for(int i=0; i<25; i++) dt[ke].nama[i]=baris[i]; dt[ke].nama[25]='\0'; ///ambil posisi karakter untuk nama dari 1baris teks itu
        c[0]=baris[26]; dt[ke].jkel=atoi(c); //jkel
        for(int i=28; i<36; i++) dt[ke].usr[i-28]=baris[i]; dt[ke].usr[8]='\0'; ///usr
        for(int i=37; i<45; i++) dt[ke].psw[i-37]=baris[i]; dt[ke].psw[8]='\0'; ///psw
        for(int i=46; i<50; i++) dt[ke].kdusr[i-46]=baris[i]; dt[ke].kdusr[4]='\0'; ///kduser
        KdUserAkhir=atoi(dt[ke].kdusr);
        ke++;
    }
    printf(_BB); printf("     Load File Data [%s] berhasil.\n",FlUser); printf(_N);
    fclose(fdt);
}

void LoadFileDataHistoryKeArray(History *dt) { ///param: pointer ke array: Histories; nama_file; true/false untuk atur kemuncul pesan
    memset(dt,0,sizeof(dt)); ///membersihkan isi array Histories
    FILE *fdt; //deklarasi variabel file data
    fdt=fopen(FlHistory,"r");  ///buka file histories.txt mode baca saja
    char baris[100], c[5]; ///baris= untuk simpan teks perbaris; c= bantuan untuk konversi
    int ke=0; ///untuk index array ke 0,1,2,3,...
    while(fgets(baris,sizeof(baris),fdt)) {  ///baca 1 baris teks dari file history.txt selama masih ada baris
        //for(int i=0; i<30; i++) printf("%c",baris[i]); printf("\n"); ///untuk testing
        memset(c,0,sizeof(c)); for(int i=0; i<2; i++) c[i]=baris[i]; dt[ke].umur=atoi(c); ///ambil posisi karakter untuk umur dari 1baris teks itu
        memset(c,0,sizeof(c)); for(int i=3; i<8; i++) c[i-3]=baris[i]; dt[ke].berat=atof(c); ///berat
        memset(c,0,sizeof(c)); for(int i=9; i<12; i++) c[i-9]=baris[i]; dt[ke].tinggi=atoi(c); ///tinggi
        dt[ke].kdaktiv[0]=baris[13]; dt[ke].kdaktiv[1]='\0'; ///aktivitas
        for(int i=15; i<23; i++) dt[ke].tgl[i-15]=baris[i]; dt[ke].tgl[8]='\0'; //tgl
        for(int i=24; i<28; i++) dt[ke].kdusr[i-24]=baris[i]; dt[ke].kdusr[4]='\0'; ///kduser
        ke++;
    }
    printf(_BB); printf("     Load File Data [%s] berhasil.\n",FlHistory); printf(_N);
    fclose(fdt);
}

void DaftarAkunBaru(User *dt1) { ///param: pointer ke array: Users
    if(BufferDtUser>0) {
        User user; ///variabel untuk inputan didalam fungsi ini
        FILE *fdt; ///deklarasi variabel tipe file
        fdt=fopen(FlUser,"a"); ///buka file users.txt mode tambah
        clrscr(); printf("\n\n");
        printf(_BB); printf("  DAFTAR AKUN BARU\n"); printf(_N);
        printf(_NG); printf("  (Sisa Buffer: %i)\n",BufferDtUser); printf(_N); 
        printf("  -----------------------------------\n"); getchar();
        printf("  N a m a  L e n g k a p             : "); scanf("%[^\n]",&user.nama);   //fgets(nama,sizeof(nama),stdin); 
        printf("  Jenis kelamin (1 Laki, 2 Perempuan): "); scanf(" %d",&user.jkel);
        printf("  Nama Akun (max 8, tanpa spasi)     : "); scanf("%8s",&user.usr);
        printf("  Password (max 8, tanpa spasi)      : "); scanf("%8s",&user.psw);
        KdUserAkhir++;
        sprintf(user.kdusr,"%d",KdUserAkhir); ///konversi int ke array char
        fprintf(fdt,"%-25s %-1d %-8s %-8s %-4s\n",user.nama,user.jkel,user.usr,user.psw,user.kdusr);  ///simpan ke file data users.txt
        LoadFileDataUserKeArray(dt1); ///refresh ulang array Users  
        BufferDtUser--; JmlDtUser++; ///BufferDtUser= sisa array User yg masih kosong; JmlDtUser= total terakhir Jml data User
        fclose(fdt);
    } else {
        printf(_NR); printf("\n\n  Maaf.. Buffer Data telah habis !\n"); printf(_N); 
        printf("  Untuk Reset Buffer, Silahkan Keluar Program lalu masuk kembali\n");
        printf("  Tekan [Enter] untuk kembali ke Menu"); getchar(); getchar();
    }
}

void TambahHistory(History *dt1,Aktivitas *dt2) { ///param: pointer ke array: Users; pointer ke array: AktivitasBMR
    if(BufferDtHistory>0) {
        History hstr; ///variabel untuk inputan didalam fungsi ini
        FILE *fdt; ///deklaraasi variabel tipe file
        fdt=fopen(FlHistory,"a"); ///buka file histories.txt mode tambah
        int pilaktiv;
        clrscr(); printf("\n\n");
        printf(_BB); printf("  TAMBAH HISTORY\n"); printf(_N);
        printf(_NG); printf("  (Sisa Buffer: %i)\n",BufferDtHistory); printf(_N); 
        printf("  -----------------------------------\n");
        printf(_BY); printf("  %s",LogNama); printf(_N); ///tampilkan nama_user yang sedang login
        printf(_NY); printf(" [%s]\n\n",LogKdUser); printf(_N); ///tampilkan kode_user yang sedang login
        getchar(); //trik
        printf("  Umur (dalam tahun)      : "); scanf("%i",&hstr.umur);
        printf("  Berat Badan (dalam kg)  : "); scanf("%f",&hstr.berat);
        printf("  Tinggi badan (dalam cm) : "); scanf("%i",&hstr.tinggi);
        printf("  Tingkat Aktivitas (BMR) :\n");
        for(int i=0;i<4;i++) printf("    %d  %s\n",i+1,dt2[i].aktivitas);  ///tampilkan isi array Aktivitas_BMR
        printf("    Pilihan: "); scanf("%i",&pilaktiv);  ///baca pilihan aktivitas
        strcpy(hstr.kdaktiv,dt2[pilaktiv-1].kdaktiv);  ///ambil kode_aktivitas berdasar pilihan lalu simpan ke hstr.kdaktiv
        printf("  Tanggal (DDMMYYY) : "); scanf("%s",&hstr.tgl);
        fprintf(fdt,"%-2i %-5.1f %-3i %-1s %-8s %-4s\n",hstr.umur,hstr.berat,hstr.tinggi,hstr.kdaktiv,hstr.tgl,LogKdUser);  ///simpan ke file data histories.txt
        LoadFileDataHistoryKeArray(dt2);  ///refresh ulang array  
        BufferDtHistory--; JmlDtHistory++;  ///BufferDtHistory= sisa array History yg masih kosong; JmlDtHistory= total terakhir Jml data history
        fclose(fdt);
    } else {
        printf(_NR); printf("\n\n  Maaf.. Buffer Data telah habis !\n"); printf(_N); 
        printf("  Untuk Reset Buffer, Silahkan Keluar Program lalu masuk kembali\n");
        printf("  Tekan [Enter] untuk kembali ke Menu"); getchar(); getchar();
    }
}

void LihatDaftarUser(User *dt1,History *dt2,Aktivitas *dt3) { ///param: pointer ke array: Users; pointer ke array: Histories; pointer ke array: AktivitasBMR
    //Yang masih perlu dibuat
    //1. Tanyakan akan di-sort berdasar: nama atau jkel
    //2. Lakukan sorting pada array: Pengguna (gunakan metode sort: Bubble)
    char nm[25];
    int hstr,activ;
    clrscr(); printf("\n\n");
    printf(_BY); printf("                                                 D A F T A R   P E N G G U N A\n"); 
    printf(_N);
    printf("  =======================================================================================================================\n");
    printf(_NY);
    printf("  N a m a                   Jenis      Umur  Berat  Tinggi   Tingkat Aktivitas                  B M I            B M R\n");
    printf("  P e n g g u n a           Kelamin                                                                              Kal/hari\n");
    printf(_N);
    printf("  =======================================================================================================================\n");
    for(int i=0;i<JmlDtUser;i++) { ///looping sebanyak jumlah data Users
        strcpy(nm,dt1[i].nama); SpasiKanan(nm); strcat(nm," ["); strcat(nm,dt1[i].kdusr); strcat(nm,"]");  ///gabung nama dengan kode_user
        hstr=-1; activ=-1; ///reset index-data untuk Histories dan AktivityMBR 
        for(int j=0;j<JmlDtHistory;j++) { ///mencari index-data Histories inputan terakhir (di array Histories) dari user ini
            if(strcmp(dt2[j].kdusr,dt1[i].kdusr)==0) hstr=j;
        }
        for(int j=0;j<4;j++) { ///mencari index-data Aktivitas inputan terakhir (di array AktivitasMBR) dari user ini
            if(strcmp(dt2[i].kdaktiv,dt3[j].kdaktiv)==0) activ=j;
        }
        if(hstr<0) {
            printf(_BG); printf("  %-25s %s",nm,(dt1[i].jkel==1?"Laki-laki":"Perempuan")); printf(_N); //tampilkan daftar data
            printf(_IY); printf("  -- data histories belum ada --\n"); printf(_N);
        } else {
            printf(_BG); 
            printf("  %-25s %s  %i    %5.1f     %3i   %s   %-15s  %s\n",nm,(dt1[i].jkel==1?"Laki-laki":"Perempuan"),dt2[hstr].umur,dt2[hstr].berat,dt2[hstr].tinggi,dt3[activ].aktivitas,BMI(dt2[hstr].berat,dt2[hstr].tinggi,2),BMR(dt1[i].jkel,dt2[hstr].umur,dt2[hstr].berat,dt2[hstr].tinggi,dt3[activ].kdaktiv)); //tampilkan daftar data 
            printf(_N);
        }
    }
    printf(_N);
    printf("  -----------------------------------------------------------------------------------------------------------------------\n");
    printf(_NY); 
    printf("  Jumlah Data: %d\n\n",JmlDtUser); 
    printf(_N); printf(_BB); 
    printf("  Keterangan:\n"); 
    printf("  B M I (Body Mass Index)  adalah Ukuran Lemak Tubuh\n"); 
    printf("  B M R (Basal Metabolic Rate) Menggunakan Rumus: MIFFLIN-ST JEOR  adalah Kebutuhan Kalori PerHari\n"); 
    printf(_N); printf(_IY);
    printf("  Catatan: Umur, Berat, Tinggi dan Tingkat Aktivitas adalah berdasar data histories inputan terakhir\n"); 
    printf(_N);
    printf("  =======================================================================================================================");
    printf("\n\n  Tekan [Enter] untuk kembali ke Menu"); getchar(); getchar();
}

void EditNamaUser(User *dt1) {
    char perbaikan, nama[26];
    clrscr(); printf("\n\n");
    printf(_BB); printf("  EDIT/UPDATE NAMA USER\n");
    printf(_N);  printf("  ----------------------\n"); 
    printf(_N); printf(_BG); printf("  %s  [%s]\n\n",LogNama,LogKdUser); printf(_N);
    getchar(); //trik
    printf("  Ketik Perbaikan Nama : "); printf(_BG); scanf("%[^\n]",&nama); printf(_N);
    do{
        getchar(); printf("\n\n  Simpan Perbaikan (Y/T) ? "); scanf("%c",&perbaikan); 
        if(toupper(perbaikan)!='Y' && toupper(perbaikan)!='T') {printf("\n  Simpan Perbaikan (Y/T) ? ");}
    } while(toupper(perbaikan)!='Y' && toupper(perbaikan)!='T');
    if(toupper(perbaikan)=='Y') {
        strcpy(LogNama,nama); ///perbaharui LogNama dngan nama (yg baru)
        char baris[100];
        FILE *fdt1, *fdt2; ///deklaraasi variabel tipe file
        ///**proses backup file data: users.txt ke users.bak
        fdt1=fopen(FlUser,"r"); ///buka file users.txt mode baca
        fdt2=fopen(FlUser2,"w"); ///buat file baru: users.bak mode write
        while((fgets(baris,sizeof(baris),fdt1))!=NULL) fputs(baris,fdt2); ///backup data (copy isi file data lama ke file data backup)
        fclose(fdt1); fclose(fdt2); 
        ///**proses buat file data baru: users.txt lalu isi dari array: Users[] kecuali kode_user yang dihapus
        fdt1=fopen(FlUser,"w"); ///buat file baru users.txt mode write (file lama ditimpah)
        for(int i=0;i<JmlDtUser;i++) { ///baca semua isi array: Users lalu simpan ke file: users.txt; kecuali kode_user yg nama-nya diperbaiki ambil dari LogNama 
            if(strcmp(dt1[i].kdusr,LogKdUser)!=0) fprintf(fdt1,"%-25s %-1d %-8s %-8s %-4s\n",dt1[i].nama,dt1[i].jkel,dt1[i].usr,dt1[i].psw,dt1[i].kdusr);  ///simpan ke file data users.txt
            else fprintf(fdt1,"%-25s %-1d %-8s %-8s %-4s\n",LogNama,dt1[i].jkel,dt1[i].usr,dt1[i].psw,dt1[i].kdusr);  ///simpan ke file data users.txt
        }
        fclose(fdt1);
        LoadFileDataUserKeArray(dt1); ///refresh ulang array Users  
    }
}

void HapusHistory(History *dt2,Aktivitas *dt3) {
    int nomor,pilnomor,activ;
    char tgl[10];
    clrscr(); printf("\n\n");
    printf(_BB); printf("  HAPUS HISTORY USER\n");
    printf(_N);  printf("  ------------------\n"); 
    printf(_N); printf(_BG); printf("  %s  [%s]\n\n",LogNama,LogKdUser); printf(_N);
    printf(_NY); printf("  Data Histories:\n"); printf(_N);
    nomor=0; activ=-1; ///set nomor dan index-data untuk AktivityMBR 
    printf("  ------------------------------------------------------------------------\n");
    printf(_NY); printf("  Nomor Umur  Berat  Tinggi   Tingkat Aktivitas                 Tanggal   \n"); printf(_N);
    printf("  ------------------------------------------------------------------------\n");
    printf(_BG);
    for(int j=0;j<JmlDtHistory;j++) { ///looping sebanyak jumlah data Histories dari user ini
        if(strcmp(dt2[j].kdusr,LogKdUser)==0) {
            ///mencari index-data Aktivitas (di array AktivitasMBR) dari user ini untuk histories ke-n
            for(int k=0;k<4;k++) if(strcmp(dt2[j].kdaktiv,dt3[k].kdaktiv)==0) activ=k;
            nomor++;
            sprintf(tgl,"%.2s-%.2s-%.4s",dt2[j].tgl,dt2[j].tgl+2,dt2[j].tgl+4); ///format bentuk tanggal jadi DD-MM-YYYY
            printf("  %4i  %4i  %5.1f     %3i   %32s  %s\n",nomor,dt2[j].umur,dt2[j].berat,dt2[j].tinggi,dt3[activ].aktivitas,tgl);
        }
    }
    if(nomor==0) { printf(_IY); printf("  data histories belum ada\n"); }
    printf(_N); printf("  ------------------------------------------------------------------------\n\n");
    printf("  Pilih Nomor History yang ingin diHapus\n  atau ketik 0 untuk Batal ? "); scanf("%i",&pilnomor);
    if(pilnomor!=0 && nomor!=0) {
        char baris[100];
        FILE *fdt1, *fdt2; ///deklaraasi variabel tipe file
        ///**proses backup file data: histories.txt ke histories.bak
        fdt1=fopen(FlHistory,"r"); ///buka file histories.txt mode baca
        fdt2=fopen(FlHistory2,"w"); ///buat file baru: histories.bak mode write
        while((fgets(baris,sizeof(baris),fdt1))!=NULL) fputs(baris,fdt2); ///backup data (copy isi file data lama ke file data backup)
        fclose(fdt1); fclose(fdt2); 
        ///**proses buat file data baru: histories.txt lalu isi dari array: Histories[] kecuali nomor_history yang dihapus
        fdt1=fopen(FlHistory,"w"); ///buat file baru histories.txt mode write (file lama ditimpah)
        for(int i=0;i<JmlDtHistory;i++) { ///baca semua isi array: Histories lalu simpan ke file: histories.txt; kecuali nomor_history yang akan dihapus
            if(i!=pilnomor-1) {
//                printf(">>%-2i %-5.1f %-3i %-1s %-8s %-4s\n",dt2[i].umur,dt2[i].berat,dt2[i].tinggi,dt2[i].kdaktiv,dt2[i].tgl,dt2[i].kdusr);  ///simpan ke file data histories.txt  
                fprintf(fdt1,"%-2i %-5.1f %-3i %-1s %-8s %-4s\n",dt2[i].umur,dt2[i].berat,dt2[i].tinggi,dt2[i].kdaktiv,dt2[i].tgl,dt2[i].kdusr);  ///simpan ke file data histories.txt  
            }
        }
        fclose(fdt1);
        ///**proses reload kembali data dari file: histories.txt yang telah berkurang datanya (ada history yang telah dihapus)
        LoadFileDataHistoryKeArray(dt2);  ///refresh ulang array  
        BufferDtHistory++; JmlDtHistory--;  ///BufferDtHistory= sisa array History yg masih kosong; JmlDtHistory= total terakhir Jml data history
    } 
}

void HapusAkunUser(User *dt1,History *dt2) {
    bool ketemu;
    char kdusr[5];
    char hapus;
    clrscr(); printf("\n\n");
    printf(_BB); printf("  HAPUS AKUN USER\n");
    printf(_N);  printf("  ---------------\n"); 
    printf("  Kode User (4 angka): "); printf(_BG); scanf("%4s",kdusr);
    ketemu=false;
    for(int i=0;i<JmlDtUser;i++) { ///looping sebanyak jumlah data Users
        if(strcmp(dt1[i].kdusr,kdusr)==0) { ///jika ketemu kode_user yang diinput
            ketemu=true;
            printf(_N); printf("  Nama Pengguna      :"); printf(_BG); printf(" %s\n",dt1[i].nama);
            printf(_N); printf("  Jenis Kelamin      :"); printf(_BG); printf(" %s\n\n",(dt1[i].jkel==1?"Laki-laki":"Perempuan"));
            break; ///karna sudah ketemu maka berhenti pencarian kode_user (keluar dari looping)
        }
    }
    if(!ketemu) {
        printf(_NR); printf("\n  Kode User Tidak Ditemukan !\n"); printf(_N);
        printf("\n  Tekan [Enter] untuk kembali ke Menu"); getchar(); getchar();     
    } else {
        printf(_NR); printf("\n  Proses Hapus Akun akan juga menghapus semua data Histories akun ini !\n"); printf(_N);
        do{
            getchar(); printf("\n  Lanjut Proses Hapus (Y/T) ? "); scanf("%c",&hapus); 
            if(toupper(hapus)!='Y' && toupper(hapus)!='T') {printf("\n  Lanjut Proses Hapus (Y/T) ? ");}
        } while(toupper(hapus)!='Y' && toupper(hapus)!='T');
        if(toupper(hapus)=='Y') {
            char baris[100];
            FILE *fdt1, *fdt2; ///deklaraasi variabel tipe file
            ///**proses backup file data: users.txt ke users.bak
            fdt1=fopen(FlUser,"r"); ///buka file users.txt mode baca
            fdt2=fopen(FlUser2,"w"); ///buat file baru: users.bak mode write
            while((fgets(baris,sizeof(baris),fdt1))!=NULL) fputs(baris,fdt2); ///backup data (copy isi file data lama ke file data backup)
            fclose(fdt1); fclose(fdt2); 
            ///**proses backup file data: histories.txt ke histories.bak
            fdt1=fopen(FlHistory,"r"); ///buka file histories.txt mode baca
            fdt2=fopen(FlHistory2,"w"); ///buat file baru: histories.bak mode write
            while((fgets(baris,sizeof(baris),fdt1))!=NULL) fputs(baris,fdt2); ///backup data (copy isi file data lama ke file data backup)
            fclose(fdt1); fclose(fdt2); 
            ///**proses buat file data baru: users.txt lalu isi dari array: Users[] kecuali kode_user yang dihapus
            fdt1=fopen(FlUser,"w"); ///buat file baru users.txt mode write (file lama ditimpah)
            for(int i=0;i<JmlDtUser;i++) { ///baca semua isi array: Users lalu simpan ke file: users.txt; kecuali kode_user yang akan dihapus
                if(strcmp(dt1[i].kdusr,kdusr)!=0) fprintf(fdt1,"%-25s %-1d %-8s %-8s %-4s\n",dt1[i].nama,dt1[i].jkel,dt1[i].usr,dt1[i].psw,dt1[i].kdusr);  ///simpan ke file data users.txt
            }
            fclose(fdt1);
            ///**proses buat file data baru: histories.txt lalu isi dari array: Histories[] kecuali kode_user yang dihapus
            fdt2=fopen(FlHistory,"w"); ///buat file baru histories.txt mode write (file lama ditimpah)
            for(int i=0;i<JmlDtHistory;i++) { ///baca semua isi array: Histories lalu simpan ke file: histories.txt; kecuali kode_user yang akan dihapus
                if(strcmp(dt2[i].kdusr,kdusr)!=0) fprintf(fdt2,"%-2i %-5.1f %-3i %-1s %-8s %-4s\n",dt2[i].umur,dt2[i].berat,dt2[i].tinggi,dt2[i].kdaktiv,dt2[i].tgl,dt2[i].kdusr);  ///simpan ke file data histories.txt  
            }
            fclose(fdt2);
            ///**proses reload kembali data dari file: users.txt dan histories.txt yang telah berkurang datanya (ada user yang telah dihapus)
            LoadFileDataUserKeArray(dt1); ///refresh ulang array Users  
            BufferDtUser++; JmlDtUser--; ///BufferDtUser= sisa array User yg masih kosong; JmlDtUser= total terakhir Jml data User
            LoadFileDataHistoryKeArray(dt2);  ///refresh ulang array  
            BufferDtHistory++; JmlDtHistory--;  ///BufferDtHistory= sisa array History yg masih kosong; JmlDtHistory= total terakhir Jml data history
        }
    }
}

void LihatDetailUser(User *dt1,History *dt2,Aktivitas *dt3,int i) { ///param: pointer ke array: Users; pointer ke array: Histories; pointer ke array: AktivitasBMR; i: 1=Admin 2=Users
    bool ketemu;
    int nomor,activ,hstr;
    char kdusr[5], tgl[10];
    char ulang;    
    ulang='Y';
    do{
        clrscr(); printf("\n\n");
        printf(_BB); printf("  LIHAT DETAIL USER\n");
        printf(_N);  printf("  -----------------\n"); 
        if(i==1) { printf("  Kode User (4 angka): "); printf(_BG); scanf("%4s",kdusr); }
        else strcpy(kdusr,LogKdUser);
        ketemu=false; nomor=0; hstr=-1; //reset ketemu, nomor dan index-data untuk Histories
        for(int i=0;i<JmlDtUser;i++) { ///looping sebanyak jumlah data Users
            if(strcmp(dt1[i].kdusr,kdusr)==0) { ///jika ketemu kode_user yang diinput
                ketemu=true;
                printf(_N); printf("  Nama Pengguna      :"); printf(_BG); printf(" %s\n",dt1[i].nama);
                printf(_N); printf("  Jenis Kelamin      :"); printf(_BG); printf(" %s\n\n",(dt1[i].jkel==1?"Laki-laki":"Perempuan"));
                printf(_NY); printf("  Data Histories:\n"); printf(_N);
                activ=-1; ///reset index-data untuk AktivityMBR 
                printf("  ------------------------------------------------------------------------\n");
                printf(_NY); printf("  Nomor Umur  Berat  Tinggi   Tingkat Aktivitas                 Tanggal   \n"); printf(_N);
                printf("  ------------------------------------------------------------------------\n");
                printf(_BG);
                for(int j=0;j<JmlDtHistory;j++) { ///looping sebanyak jumlah data Histories dari user ini
                    if(strcmp(dt2[j].kdusr,dt1[i].kdusr)==0) {
                        ///mencari index-data Aktivitas (di array AktivitasMBR) dari user ini untuk histories ke-n
                        hstr=j; //menyimpan index-data Histories terakhir
                        for(int k=0;k<4;k++) if(strcmp(dt2[j].kdaktiv,dt3[k].kdaktiv)==0) activ=k;
                        nomor++;
                        sprintf(tgl,"%.2s-%.2s-%.4s",dt2[j].tgl,dt2[j].tgl+2,dt2[j].tgl+4); ///format bentuk tanggal jadi DD-MM-YYYY
                        printf("  %4i  %4i  %5.1f     %3i   %32s  %s\n",nomor,dt2[j].umur,dt2[j].berat,dt2[j].tinggi,dt3[activ].aktivitas,tgl);
                    }
                }
                if(nomor==0) {printf(_IY); printf("  data histories belum ada\n");}
                printf(_N); printf("  ------------------------------------------------------------------------\n\n");
                if(nomor>0) {
                    printf(_BY); printf("  Berdasar data Histories terakhir:\n"); printf(_N);
                    printf("\n  Hasil BMI dan Anjuran :\n"); printf(_BG); printf("%s\n",BMI(dt2[hstr].berat,dt2[hstr].tinggi,1)); printf(_N);
                    printf("\n  Hasil BMR :\n"); printf(_BG);
                    printf("  Anda membutuhkan: %s Kalori/Hari\n",BMR(dt1[i].jkel,dt2[hstr].umur,dt2[hstr].berat,dt2[hstr].tinggi,dt3[activ].kdaktiv)); 
                    printf("  Silahkan pilih jenis dan jumlah makanan sesuai ukuran kalori/gram nya"); printf(_N);
                }
                break; ///karna sudah ketemu maka berhenti pencarian kode_user
            } 
        }
        if(i==1) { ///jika panggilan fungsi ini dari Admin
            if(!ketemu) { printf(_NR); printf("\n  Kode User Tidak Ditemukan !\n"); printf(_N);}
            do{
                printf("\n\n  Cari lagi (Y/T)? "); scanf("%c",&ulang); 
                if(toupper(ulang)!='Y' && toupper(ulang)!='T') {printf("\n\n  Cari lagi (Y/T)? ");}
            } while(toupper(ulang)!='Y' && toupper(ulang)!='T');
        } else { printf("\n\n  Tekan [Enter] untuk kembali ke Menu"); getchar(); getchar(); ulang='T'; }
    } while(toupper(ulang)=='Y');
}

void MenuAdmin(User *dt1,History *dt2,Aktivitas *dt3) { ///param: pointer ke array: Users; pointer ke array: Histories; pointer ke array: AktivitasBMR
    clrscr(); printf("\n\n"); 
    printf(_NG); printf("\n  Loading File Data ke Memory..\n"); printf(_N);
    LoadFileDataUserKeArray(dt1); ///baca dari file data: user.txt lalu isi ke array: Users
    LoadFileDataHistoryKeArray(dt2); ///baca dari file data: history.txt lalu isi ke array: Histories
    sleep(2);
    int pilih;
    do {
        clrscr(); printf("\n\n"); 
        printf(_BY);
        printf("  ==================================================\n");
        printf("            A   P   L   I   K   A   S   I           \n");
        printf("  BASAL METABOLIC RATE (BMR) & BODY MASS INDEX (BMI)\n");
        printf("  ==================================================\n\n");
        printf(_N); printf(_BB); printf("  Logon by");
        printf(_N); printf(_BG); printf(" %s\n\n",LogNama); printf(_N);
        printf("                 M E N U  A D M I N\n"); 
        printf("                 ------------------\n\n");
        printf(_N); printf(_BG);
        printf("                 1  Lihat Daftar Users\n");
        printf("                 2  Lihat Detail User\n");
        printf("                 3  Hapus Akun User + Histories\n");
        printf("                 4  Exit\n");
        printf(_BB); printf("\n");
        printf("                 Pilihan: "); scanf("%i",&pilih);
        printf(_N);
        switch (pilih) {
            case 1: LihatDaftarUser(dt1,dt2,dt3); break;
            case 2: LihatDetailUser(dt1,dt2,dt3,1); break;
            case 3: HapusAkunUser(dt1,dt2); break;
            case 4: menu=3; break;
            default: break;
        }
    } while (pilih!=4);
}

void MenuUser(User *dt1,History *dt2,Aktivitas *dt3) { ///param: pointer ke array: Users; pointer ke array: Histories; pointer ke array: AktivitasBMR
    clrscr(); printf("\n\n"); 
    printf(_NG); printf("\n  Loading File Data ke Memory..\n"); printf(_N);
    LoadFileDataUserKeArray(dt1); ///baca dari file data: user.txt lalu isi ke array: Users
    LoadFileDataHistoryKeArray(dt2); ///baca dari file data: history.txt lalu isi ke array: Histories
    sleep(2);
    int pilih;
    do {
        clrscr(); printf("\n\n"); 
        printf(_BY);
        printf("  ==================================================\n");
        printf("            A   P   L   I   K   A   S   I           \n");
        printf("  BASAL METABOLIC RATE (BMR) & BODY MASS INDEX (BMI)\n");
        printf("  ==================================================\n\n");
        printf(_N); printf(_BB); printf("  Logon by");
        printf(_N); printf(_BG); printf(" %s  [%s]\n\n",LogNama,LogKdUser); printf(_N);
        printf("                 M E N U  U S E R\n"); 
        printf("                 ----------------\n\n");
        printf(_N); printf(_BG);
        printf("                 1  Lihat Detail Data\n");
        printf("                 2  Tambah History\n");
        printf("                 3  Edit/Update Nama\n");
        printf("                 4  Hapus History\n");
        printf("                 5  Exit\n");
        printf(_BB); printf("\n");
        printf("                 Pilihan: "); scanf("%i",&pilih);
        printf(_N);
        switch (pilih) {
            case 1: LihatDetailUser(dt1,dt2,dt3,2); break;
            case 2: TambahHistory(dt2,dt3); break;
            case 3: EditNamaUser(dt1); break;
            case 4: HapusHistory(dt2,dt3); break;
            case 5: menu=3; break;
            default: break;
        }
    } while (pilih!=5);
}

void Login() {
    FILE *fdt; ///deklarasi variabel tipe file
    fdt=fopen(FlUser,"r"); ///buka file users.txt mode baca saja
    char baris[100]; ///baris= untuk simpan teks perbaris
    int ke=0, j;
    char usr[9], psw[9], usr2[9], psw2[9];  ///variabel untuk inputan didalam fungsi ini
    LogLev=0; strcpy(LogNama,"none"); memset(LogKdUser,0,sizeof(LogKdUser)); ///reset LogLev=0, LogNama="none" dan LogKdUser=""
    clrscr(); printf("\n\n");
    printf(_BB); printf("  L O G I N\n"); printf(_N);
    printf("  --------------------\n");
    printf("  User     : "); scanf("%8s",usr);  
    printf("  Password : "); scanf("%8s",psw);
    if(strcmp(usr,AdminUsr)==0 && strcmp(psw,AdminPsw)==0 ) { ///jika login adalah Admin
        LogLev=1;
        strcpy(LogNama,"Admin Aplikasi"); 
        strcpy(LogKdUser,"0000");
    } else { ///jika login bukan Admin
        while(fgets(baris,sizeof(baris),fdt)) {  ///baca 1 baris teks dari file Users.txt selama masih ada baris
            for(int i=28; i<36; i++) if(baris[i]!=' ') usr2[i-28]=baris[i]; else usr2[i-28]='\0'; ///ambil posisi karakter untuk user dari 1baris teks itu
            for(int i=37; i<45; i++) if(baris[i]!=' ') psw2[i-37]=baris[i]; else psw2[i-37]='\0'; ///ambil posisi karakter untuk password dari 1baris teks itu
            if(strcmp(usr2,usr)==0 && strcmp(psw2,psw)==0) { ///jika user & password yang diiput sama dengan user & password dari file data
                LogLev=2;
                for(int i=0; i<25; i++)  LogNama[i]=baris[i]; ///ambil posisi karakter untuk nama dari 1baris teks itu
                SpasiKanan(LogNama);
                for(int i=46; i<50; i++) LogKdUser[i-46]=baris[i]; LogKdUser[4]='\0'; ///ambil posisi karakter untuk kode_user dari 1baris teks itu
                break;
            }
            ke++;
        }
    }
    fclose(fdt);
}

void SpasiKanan(char *c) { ///untuk menghapus spasi dibagian kanan teks
    int len=strlen(c);
    while(len>0 && c[len-1]==' ') { c[len-1]='\0'; len--; }
}

void main() {
    clrscr(); printf("\n\n");

    printf(_NG); printf("\n  Periksa File Data..\n"); printf(_N);
    JmlDtUser=PeriksaFileData(FlUser); ///periksa file data: users.txt; kalau belum ada maka buat file baru; kalau sudah ada hitung isinya
    User Users[JmlDtUser+BufferDtUser]; ///buat array: Users sebanyak jumlah data yang ada difile users.txt + array kosong untuk inputan data baru
    if(JmlDtUser==0) KdUserAkhir=1000;  ///jika file users.txt kosong atau baru dibuat, maka set kode user pertama kali

    JmlDtHistory=PeriksaFileData(FlHistory); ///periksa file data: histories.txt; kalau belum ada maka buat file baru; kalau sudah ada hitung isinya
    History Histories[JmlDtHistory+BufferDtHistory]; ///buat array: Histories sebanyak jumlah data yang ada difile histories.txt + array kosong untuk inputan data baru

    ///CATATAN: Dua Array diatas: Users[] dan Histories[] adalah array utama tempat data yang akan diisi dari 2 file teks utama: users.txt dan histories.txt
    ///         Dua Array ini yang akan digunakan oleh semua fungsi() untuk baca dan tampilkan data

    //buat array (AktivitasBMR) dan isi data untuk Aktivitas Standar BMR
    Aktivitas AktivitasBMR[4];
    strcpy(AktivitasBMR[0].aktivitas,"Sedentari (Tidak Aktif)         ");
    strcpy(AktivitasBMR[0].kdaktiv,"1"); AktivitasBMR[0].kdaktiv[1]='\0';
    strcpy(AktivitasBMR[1].aktivitas,"Ringan (Olahraga 1-3hari/minggu)");
    strcpy(AktivitasBMR[1].kdaktiv,"2"); AktivitasBMR[1].kdaktiv[1]='\0';
    strcpy(AktivitasBMR[2].aktivitas,"Sedang (Olahraga 3-5hari/minggu)");
    strcpy(AktivitasBMR[2].kdaktiv,"3"); AktivitasBMR[2].kdaktiv[1]='\0';
    strcpy(AktivitasBMR[3].aktivitas,"Berat (Olahraga 6-7hari/minggu  ");
    strcpy(AktivitasBMR[3].kdaktiv,"4"); AktivitasBMR[3].kdaktiv[1]='\0';

    sleep(3);

    LogLev=0; strcpy(LogNama,"none"); memset(LogKdUser,0,sizeof(LogKdUser)); //set awal LogLev, LogNama dan LogKdUser

// LoadFileDataUserKeArray(Users); ///baca dari file data: user.txt lalu isi ke array: Users
// LoadFileDataHistoryKeArray(Histories); ///baca dari file data: history.txt lalu isi ke array: Histories
// strcpy(LogKdUser,"1001");
// HapusHistory(Histories,AktivitasBMR);

    do {
        clrscr(); printf("\n\n"); 
        printf(_BY);
        printf("  ==================================================\n");
        printf("            A   P   L   I   K   A   S   I           \n");
        printf("  BASAL METABOLIC RATE (BMR) & BODY MASS INDEX (BMI)\n");
        printf("  ==================================================\n\n");
        if(strcmp(LogNama,"none")!=0)  { ///jika sudah ada yang login; LogNama != "none"
            printf(_N); printf(_BB); printf("  Logon by");
            printf(_N); printf(_BG); printf(" %s  [%s]\n\n",LogNama,LogKdUser);
        }
        printf(_N);
        printf("                 -------------------\n");
        printf(_N); printf(_BG);
        printf("                 1  Login\n");
        printf("                 2  Daftar Akun Baru\n");
        printf("                 3  Exit\n");
        printf(_N);
        printf("                 -------------------\n\n");
        printf(_BB);
        printf("                 Pilihan: "); scanf("%i",&menu);
        printf(_N);
        switch (menu) {
            case 1:
                Login();
                if(LogLev==1) MenuAdmin(Users,Histories,AktivitasBMR);
                else if(LogLev==2) MenuUser(Users,Histories,AktivitasBMR);
                else { printf(_NR); printf("\n  User atau Password Salah atau Akun Belum Terdaftar !"); printf(_N); getchar(); getchar(); }
                break;
            case 2: DaftarAkunBaru(Users); break;
            default: break;
        }
    } while (menu!=3);

    printf(_BB); printf("\n\n  Program Selesai..\n\n"); printf(_N);
}

